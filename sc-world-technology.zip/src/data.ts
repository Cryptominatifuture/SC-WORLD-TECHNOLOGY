import { Service, Course, Stat, SocialLink, JobCard } from './types';

export const services: Service[] = [
  {
    id: 'it-education',
    title: 'IT Education',
    description: 'Advanced technical curriculum designed to meet global industry standards.',
    icon: 'Laptop',
    link: 'https://www.scworldtechnology.in/2026/02/web-development-compnay-in-jabalpur-sc.html'
  },
  {
    id: 'skill-training',
    title: 'Skill Training',
    description: 'Specialized vocational training programs to enhance employability.',
    icon: 'GraduationCap',
    link: 'https://www.scworldtechnology.in/2026/02/skill-training-in-jabalpur-sc-world.html'
  },
  {
    id: 'computer-courses',
    title: 'Computer Courses',
    description: 'From Basic to Advanced certifications for all age groups.',
    icon: 'Monitor',
    link: 'https://www.scworldtechnology.in/2026/02/best-computer-institute-in-jabalpur-sc.html'
  },
  {
    id: 'csc-governance',
    title: 'CSC E-Governance',
    description: 'Direct access to Government-to-Citizen (G2C) digital services.',
    icon: 'Building',
    link: 'https://www.scworldtechnology.in/2026/02/csc-digital-seva-services-india-sc.html'
  },
  {
    id: 'job-updates',
    title: 'Jobs Updates',
    description: 'Real-time notifications for Government and Private sector vacancies.',
    icon: 'Briefcase',
    link: 'https://www.scworldtechnology.in/2026/02/jabalpur-private-job-vacancy-2026.html'
  },
  {
    id: 'citizen-services',
    title: 'Citizen Services',
    description: 'Hassle-free online and offline assistance for documentation.',
    icon: 'Handshake',
    link: 'https://www.scworldtechnology.in/2026/02/online-citizen-services-jabalpur-sc.html'
  }
];

export const courses: Course[] = [
  {
    id: 'computer-basic',
    title: 'Computer Basic',
    description: 'MS Office, Internet, and Operating Systems for beginners.'
  },
  {
    id: 'advanced-it',
    title: 'Advanced IT',
    description: 'Web Development, Tally Prime, and Graphic Designing.'
  },
  {
    id: 'skill-india',
    title: 'Skill India',
    description: 'Government certified vocational training programs.'
  },
  {
    id: 'csc-training',
    title: 'CSC Training',
    description: 'Become a certified CSC operator and serve your community.'
  },
  {
    id: 'free-vocational',
    title: 'Free Vocational Training',
    description: 'Provides practical job skills to help people get employment or start their own work.'
  },
  {
    id: 'free-ai',
    title: 'Free AI Courses',
    description: 'Learn the basics of Artificial Intelligence and practical AI tools to improve skills and career opportunities.'
  }
];

export const stats: Stat[] = [
  {
    id: 'jobs-available',
    icon: 'Briefcase',
    target: 12500,
    label: 'Jobs Available',
    suffix: '+'
  },
  {
    id: 'services-provided',
    icon: 'Settings',
    target: 10000,
    label: 'Services',
    suffix: '+'
  },
  {
    id: 'opportunities-created',
    icon: 'Lightbulb',
    target: 50000,
    label: 'Opportunities',
    suffix: '+'
  },
  {
    id: 'joined-candidates',
    icon: 'Users',
    target: 100000,
    label: 'Joined Candidates',
    suffix: '+'
  },
  {
    id: 'daily-visitors',
    icon: 'TrendingUp',
    target: 1000000,
    label: 'Daily Visitors',
    suffix: '+'
  }
];

export const socialLinks: SocialLink[] = [
  {
    platform: 'WhatsApp',
    icon: 'MessageCircle',
    url: 'https://wa.me/916264169913',
    color: '#25D366'
  },
  {
    platform: 'Facebook',
    icon: 'Facebook',
    url: 'https://www.facebook.com/share/12MAD5K5hn6',
    color: '#1877F2'
  },
  {
    platform: 'Instagram',
    icon: 'Instagram',
    url: 'https://www.instagram.com/scworldtechnology?igsh=OGlxNTlqY2N4bmsz',
    color: '#E4405F'
  },
  {
    platform: 'Twitter',
    icon: 'Twitter',
    url: 'https://x.com/scworldtechno',
    color: '#1DA1F2'
  },
  {
    platform: 'YouTube',
    icon: 'Youtube',
    url: 'https://youtube.com/@scworldtechnology?si=QgfGQ8qajFm-Wd15',
    color: '#FF0000'
  },
  {
    platform: 'LinkedIn',
    icon: 'Linkedin',
    url: 'https://www.linkedin.com/in/mohammad-shafique-a239a827b?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app',
    color: '#0A66C2'
  },
  {
    platform: 'Telegram',
    icon: 'Send',
    url: 'https://t.me/scworldtechnology',
    color: '#0088CC'
  },
  {
    platform: 'Pinterest',
    icon: 'Compass',
    url: 'https://pin.it/1jfoT9arP',
    color: '#E60023'
  }
];

export const jobUpdates: JobCard[] = [
  {
    id: 'govt-job',
    title: 'Government Jobs',
    description: 'Find latest Government Job notifications in India with daily updates on vacancies, eligibility, application dates, and exam details. Apply online for central and state govt jobs.',
    tag: 'Government'
  },
  {
    id: 'private-job',
    title: 'Private Jobs',
    description: 'Explore latest Private Job openings in India with daily updates on company vacancies, eligibility, and application details. Find and apply for private sector jobs easily.',
    tag: 'Private'
  }
];

export const getBotResponse = (text: string): string => {
  const msg = text.toLowerCase();
  
  if (msg.includes('course')) {
    return '📚 **Courses & Training Available:**<br>• Computer Basic (MS Office)<br>• Web Development (HTML/CSS/JS)<br>• Advanced IT (Tally Prime, Graphic Design)<br>• Skill India Vocations<br>• Free AI Courses<br><br>👉 Tap headers to explore!';
  } else if (msg.includes('ai') || msg.includes('chatbot')) {
    return '🤖 **AI Services:**<br>• Custom Website Chatbots<br>• WhatsApp Automation Integration<br>• Business AI Agents & Tools<br>• AI-centric Training Programs<br><br>Let us build your next smart asset!';
  } else if (msg.includes('website') || msg.includes('web')) {
    return '💻 **Website & App Development:**<br>• Custom Business Websites<br>• SEO Optimization<br>• Responsive Portals<br>• High-performance UI/UX design<br>• Free Cloud Hosting setup';
  } else if (msg.includes('seo') || msg.includes('ranking')) {
    return '📈 **SEO & Digital Marketing Services:**<br>• Google Search Console Optimization<br>• Organic Ranking & Keyword Research<br>• Social Media Marketing (SMM)<br>• Digital Presence Boosting';
  } else if (msg.includes('job') || msg.includes('vacancy') || msg.includes('update')) {
    return '🧑‍💼 **Real-time Job Updates:**<br>• Daily Government & Railway updates<br>• Bank & SSC vacancy links<br>• Private IT & non-IT jobs openings<br><br>👉 Follow our WhatsApp Channel for instant notifications!';
  } else if (msg.includes('contact') || msg.includes('call') || msg.includes('phone') || msg.includes('number')) {
    return '📞 **Get In Touch:**<br>• Call/WhatsApp: **+91 6264169913**<br>• Email: scworldtechnology@gmail.com<br>• Address: Jabalpur, MP, India<br>• Web: [scworldtechnology.in](https://www.scworldtechnology.in)';
  } else if (msg.includes('hello') || msg.includes('hi') || msg.includes('hey')) {
    return '👋 Hello! I am your **SC World Technology Assistant**.<br><br>How can I assist you today? You can type keywords like **Courses**, **Jobs**, **Website**, **SEO**, **Contact**, or **AI** to get immediate premium services details!';
  }
  
  return '🤝 Thank you for reaching out to **SC WORLD TECHNOLOGY**!<br><br>For custom software, certification verification, or training inquiries, please contact our support team at **+91-6264169913** or email us at **scworldtechnology@gmail.com**.';
};

export const videos = [
  {
    id: 'vid1',
    title: 'Computer Courses & Career',
    embedId: '24OQYghVRQE',
    si: 'ENaViZ07sQ8R4-tI'
  },
  {
    id: 'vid2',
    title: 'IT & Digital Services Demo',
    embedId: 'NhKA5lxJscU',
    si: 's1dtETPil7Ksy2Rb'
  },
  {
    id: 'vid3',
    title: 'Free AI Training & Projects',
    embedId: 'mo0njymz1BU',
    si: 'JUabLvoZ3unQ3Hl0'
  },
  {
    id: 'vid4',
    title: 'CSC e-Governance Benefits',
    embedId: 'ezFsG20zkwY',
    si: '9_X3vGm0Key1b76W'
  }
];
