import React, { useState, useEffect } from 'react';
import { 
  Laptop, 
  GraduationCap, 
  Monitor, 
  Building, 
  Briefcase, 
  Handshake, 
  Settings, 
  Lightbulb, 
  Users, 
  TrendingUp, 
  Facebook, 
  Instagram, 
  Twitter, 
  Youtube, 
  Linkedin, 
  Send, 
  Compass, 
  MessageCircle, 
  Home, 
  Grid, 
  Bot, 
  Video, 
  Phone, 
  Mail, 
  Globe, 
  Calendar, 
  Award, 
  Download, 
  Search, 
  ArrowUpRight, 
  Menu, 
  X, 
  CheckCircle2, 
  Play, 
  ExternalLink,
  ChevronRight 
} from 'lucide-react';
import { services, courses, stats, socialLinks, jobUpdates, videos } from './data';
import PhoneHeader from './components/PhoneHeader';
import AIChatBot from './components/AIChatBot';
import StatsGrid from './components/StatsGrid';
import PlayStoreBanner from './components/PlayStoreBanner';

export default function App() {
  // Mobile app active state
  const [activeTab, setActiveTab] = useState<'home' | 'services' | 'courses' | 'jobs' | 'chat'>('home');
  const [searchQuery, setSearchQuery] = useState('');
  const [deviceMode, setDeviceMode] = useState<'phone' | 'fullscreen'>('phone');
  const [cookieConsent, setCookieConsent] = useState<boolean>(() => {
    const saved = localStorage.getItem('cookieConsent');
    return saved ? true : false;
  });
  const [announcementNotify, setAnnouncementNotify] = useState<string>('');

  // Auto notification messages from activities
  const triggerNotification = (msg: string) => {
    setAnnouncementNotify(msg);
    setTimeout(() => {
      setAnnouncementNotify('');
    }, 4000);
  };

  const handleCookieAccept = () => {
    localStorage.setItem('cookieConsent', 'accepted');
    setCookieConsent(true);
    triggerNotification("Cookie preferences saved successfully!");
  };

  const handleCookieDecline = () => {
    localStorage.setItem('cookieConsent', 'declined');
    setCookieConsent(true);
    triggerNotification("Analytics cookies declined.");
  };

  // Searching filter variables
  const filteredServices = services.filter(s => 
    s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredCourses = courses.filter(c => 
    c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Icon mapper helper
  const renderServiceIcon = (iconName: string) => {
    switch (iconName) {
      case 'Laptop': return <Laptop className="w-6 h-6 text-blue-500" />;
      case 'GraduationCap': return <GraduationCap className="w-6 h-6 text-[#ff8c00]" />;
      case 'Monitor': return <Monitor className="w-6 h-6 text-emerald-500" />;
      case 'Building': return <Building className="w-6 h-6 text-purple-500" />;
      case 'Briefcase': return <Briefcase className="w-6 h-6 text-rose-500" />;
      case 'Handshake': return <Handshake className="w-6 h-6 text-amber-500" />;
      default: return <Settings className="w-6 h-6 text-blue-500" />;
    }
  };

  // Social Icon renderer mapping
  const renderSocialIcon = (platform: string) => {
    switch (platform) {
      case 'WhatsApp': return <MessageCircle className="w-4 h-4 text-white" />;
      case 'Facebook': return <Facebook className="w-4 h-4 text-white" />;
      case 'Instagram': return <Instagram className="w-4 h-4 text-white" />;
      case 'Twitter': return <Twitter className="w-4 h-4 text-white" />;
      case 'YouTube': return <Youtube className="w-4 h-4 text-white" />;
      case 'LinkedIn': return <Linkedin className="w-4 h-4 text-white" />;
      case 'Telegram': return <Send className="w-4 h-4 text-white" />;
      case 'Pinterest': return <Compass className="w-4 h-4 text-white" />;
      default: return <Globe className="w-4 h-4 text-white" />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col md:flex-row font-sans">
      
      {/* ----------------- LEFT PANE: WIDESCREEN PRODUCT DASHBOARD ----------------- */}
      {/* Hidden when simulator is in native standalone view, but highly gorgeous on normal desktop */}
      <div className={`flex-1 p-6 lg:p-10 flex flex-col justify-between ${deviceMode === 'fullscreen' ? 'hidden md:flex md:max-w-xs border-r border-slate-900 bg-slate-950/70' : 'md:max-w-2xl border-r border-slate-900/95 bg-gradient-to-b from-[#001124] to-slate-950'}`}>
        
        <div className="space-y-6">
          {/* Logo and Brand Title Header */}
          <div className="flex items-center gap-3">
            <img 
              src="https://i.ibb.co/ch5s8fj4/file-00000000ac707230bdc67211044b6545.png" 
              alt="SC World Logo" 
              className="w-12 h-12 rounded-full border border-blue-500/20 object-cover"
              referrerPolicy="no-referrer"
            />
            <div>
              <h1 className="text-xl font-extrabold tracking-tight text-white font-display select-none">
                SC WORLD <span className="text-blue-500">TECH</span>
              </h1>
              <p className="text-[10px] uppercase font-bold text-slate-400 tracking-widest font-mono">
                IT & COMPUTER TRAINING INSTITUTE
              </p>
            </div>
          </div>

          <div className="border-l-2 border-orange-500 pl-4 py-1">
            <span className="text-xs font-mono font-medium text-orange-400 uppercase tracking-wide bg-orange-950/40 px-2 py-0.5 rounded">
              Official Media Release 2026
            </span>
            <p className="text-sm font-semibold text-slate-100 mt-2">
              &ldquo;Best IT & Computer Training Institute for Skill Development and Job Oriented Courses in India.&rdquo;
            </p>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed max-w-md">
            SC World Technology is the premier technical workspace empowering youth across India with career-readiness training, CSC e-government services, certified skill diplomas, and daily updates regarding private and government job opportunities.
          </p>

          {/* Device toggle switches */}
          <div className="bg-slate-900/90 p-3 rounded-2xl border border-slate-800/80 space-y-2">
            <span className="text-[10px] text-slate-400 font-mono tracking-wider uppercase block">
              Viewport Display Control
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setDeviceMode('phone')}
                className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all outline-none ${
                  deviceMode === 'phone'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'bg-slate-950 text-slate-400 hover:text-slate-200 hover:bg-slate-950/50'
                }`}
              >
                📱 Phone Shell
              </button>
              <button
                onClick={() => setDeviceMode('fullscreen')}
                className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all outline-none ${
                  deviceMode === 'fullscreen'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'bg-slate-950 text-slate-400 hover:text-slate-200 hover:bg-slate-950/50'
                }`}
              >
                💻 Modern Desktop View
              </button>
            </div>
          </div>

          {/* Quick links & Download metrics */}
          <div className="space-y-3.5 pt-2">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
              Core Deliverables & Actions
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <a 
                href="https://whatsapp.com/channel/0029VaA9bbSJuyA6RxHrS12M" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="p-3 bg-slate-900 hover:bg-slate-800 border border-slate-800/80 rounded-xl flex items-center justify-between text-xs font-semibold transition-all group"
              >
                <div className="flex items-center gap-2">
                  <span className="text-green-500 text-base">🟢</span>
                  <div>
                    <div className="text-white">Follow Job Hub</div>
                    <div className="text-[9px] text-slate-500 font-normal">WhatsApp Channel</div>
                  </div>
                </div>
                <ArrowUpRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-white transition-colors" />
              </a>

              <a 
                href="https://www.scworldtechnology.in/p/sign-up-form.html" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="p-3 bg-slate-900 hover:bg-slate-800 border border-slate-800/80 rounded-xl flex items-center justify-between text-xs font-semibold transition-all group"
              >
                <div className="flex items-center gap-2">
                  <span className="text-[#ff8c00] text-base">📝</span>
                  <div>
                    <div className="text-white">Apply Registration</div>
                    <div className="text-[9px] text-slate-500 font-normal">Online Training Portal</div>
                  </div>
                </div>
                <ArrowUpRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-white transition-colors" />
              </a>
            </div>
          </div>

          {/* Interactive support info card */}
          <div className="bg-gradient-to-r from-blue-950/50 to-indigo-950/30 p-4 rounded-2xl border border-blue-900/30">
            <div className="flex items-center gap-3 mb-2.5">
              <div className="px-2 py-0.5 bg-blue-500/10 text-blue-400 text-[10px] font-mono rounded font-semibold border border-blue-400/20">
                ACTIVE HELPLINE
              </div>
              <span className="text-[10px] text-slate-400 font-mono">MP Jabalpur Center</span>
            </div>
            <div className="flex flex-col gap-1.5 text-xs">
              <div className="flex items-center gap-2 text-slate-200">
                <Phone className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                <span className="font-semibold">+91 6264169913</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <Mail className="w-3.5 h-3.5 text-[#ff8c00] shrink-0" />
                <span className="hover:underline">scworldtechnology@gmail.com</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer info brand */}
        <div className="pt-6 border-t border-slate-900 text-[11px] text-slate-500 font-mono flex flex-col sm:flex-row gap-2 justify-between">
          <span>&copy; SC World Technology Team</span>
          <span>Blogger-Synced Applet v2.4</span>
        </div>
      </div>

      {/* ----------------- RIGHT PANE: APP SIMULATOR CONTAINER ----------------- */}
      <div className={`flex-1 flex items-center justify-center p-3 select-none ${deviceMode === 'fullscreen' ? 'w-full' : 'bg-slate-950'}`}>
        
        {/* Smartphone Shell Frame Wrapper or Full-browser adaptation */}
        <div className={`w-full transition-all duration-300 relative ${
          deviceMode === 'fullscreen' 
            ? 'h-full max-w-7xl' 
            : 'max-w-[420px] aspect-[9/19] h-[85vh] min-h-[680px] max-h-[880px] border-[8px] border-slate-800 rounded-[38px] shadow-[0_25px_60px_rgba(0,0,0,0.8)] overflow-hidden bg-slate-900 flex flex-col border-slate-900/80 outline-4 outline-slate-800'
        }`}>
          
          {/* Hardware notch / speaker simulated dummy */}
          {!deviceMode || deviceMode === 'phone' ? (
            <>
              {/* iOS style Top Island Sensor mock bar */}
              <div className="absolute top-2 left-1/2 -translate-x-1/2 w-32 h-6 bg-black rounded-2xl z-50 flex items-center justify-center gap-1.5 px-3 pointer-events-none border border-white/5 shadow-inner">
                <div className="w-2.5 h-2.5 bg-blue-900/90 rounded-full border border-blue-500/30"></div>
                <div className="w-12 h-1 bg-slate-900 rounded-full"></div>
                <span className="text-[8px] text-emerald-400 font-mono shrink-0 animate-pulse">●</span>
              </div>
              
              {/* Dynamic Header */}
              <PhoneHeader />
            </>
          ) : null}

          {/* Interactive Live Banner Notice */}
          <div className="bg-[#ff8c00] text-black text-xs py-2 px-4 shadow-sm overflow-hidden select-none shrink-0 relative flex items-center gap-2">
            <span className="font-bold uppercase tracking-wider bg-black text-white text-[9px] px-1.5 py-0.5 rounded shrink-0">
              LIVE
            </span>
            <div className="flex-1 whitespace-nowrap overflow-hidden relative">
              <span className="inline-block animate-sc-marquee font-bold tracking-wide">
                🔥 Latest Vacancies: State Boards, Indian Railways, Staff Selection recruitment. Online Admissions open for Web Development, Tally Prime, and Digital Marketing!
              </span>
            </div>
          </div>

          {/* Inner Display Screen Area */}
          <div className="flex-1 overflow-y-auto bg-slate-50 text-slate-800 relative flex flex-col">
            
            {/* -------------------- TAB CONTENT: HOME -------------------- */}
            {activeTab === 'home' && (
              <div className="flex-1 flex flex-col">
                {/* Hero Header with Animated Gradient */}
                <div className="bg-gradient-to-br from-[#eaf3ff] via-white to-[#fff2e6] px-5 py-8 text-center border-b border-slate-200 select-none relative animate-sc-gradient overflow-hidden shrink-0">
                  
                  {/* Floating brand icon logo */}
                  <div className="flex justify-center mb-4">
                    <img 
                      src="https://i.ibb.co/ch5s8fj4/file-00000000ac707230bdc67211044b6545.png" 
                      alt="SC World Logo icon"
                      className="w-28 h-28 rounded-full border-4 border-white shadow-lg animate-sc-logo-float animate-sc-logo-glow object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>

                  <h2 className="text-2xl font-extrabold text-[#002147] tracking-tight font-display">
                    SC WORLD TECHNOLOGY
                  </h2>
                  <p className="text-xs text-slate-600 font-semibold tracking-wide mt-1.5">
                    Find Government Vacancies, Private Jobs & FREE Certified IT Courses
                  </p>

                  {/* Immediate Action Buttons */}
                  <div className="flex flex-col sm:flex-row justify-center gap-2.5 mt-5">
                    <a 
                      href="https://whatsapp.com/channel/0029VaA9bbSJuyA6RxHrS12M" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-full shadow-md transition-all active:scale-95 gap-1"
                    >
                      <span>Latest Jobs Updates</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </a>
                    
                    <button 
                      onClick={() => setActiveTab('courses')}
                      className="inline-flex items-center justify-center px-4 py-2 bg-[#ff8c00] hover:bg-orange-600 text-white font-bold text-xs rounded-full shadow-md transition-all active:scale-95 gap-1"
                    >
                      <span>Free Computer Courses</span>
                    </button>
                    
                    <a 
                      href="https://www.scworldtechnology.in/p/sign-up-form.html" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-full shadow-md transition-all active:scale-95 gap-1"
                    >
                      <span>Register / Apply Online</span>
                    </a>
                  </div>
                </div>

                {/* Main scrollable body segments */}
                <div className="p-5 space-y-6 flex-1 bg-slate-50">
                  
                  {/* Search Bar Shortcut */}
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                    <input 
                      type="text" 
                      placeholder="Search courses, job vacancies, updates..."
                      value={searchQuery}
                      onChange={(e) => {
                        setSearchQuery(e.target.value);
                        if (searchQuery) {
                          // Quick jump to courses tab when searching
                          setActiveTab('courses');
                        }
                      }}
                      className="w-full bg-white border border-slate-200 rounded-xl pl-9.5 pr-4 py-2.5 text-xs outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all font-sans"
                    />
                  </div>

                  {/* Welcome Quote Description Segment */}
                  <div className="bg-white border border-slate-100 rounded-2xl p-4 shadow-xs">
                    <span className="text-[10px] text-[#ff6f00] font-bold uppercase tracking-wider block mb-1">
                      ABOUT THE ACADEMY
                    </span>
                    <h3 className="text-sm font-bold text-[#002147] mb-2 font-display">
                      Empowering Technical Careers Globally
                    </h3>
                    <p className="text-xs text-slate-500 leading-relaxed font-sans font-medium">
                      SC World Technology is the absolute best IT training center providing computer educational certificates, certified digital projects, and offline e-governance service support.
                    </p>
                    <div className="mt-3.5 flex flex-wrap gap-2">
                      <span className="bg-slate-100 text-slate-600 text-[10px] font-bold px-2.5 py-1 rounded-full">
                        ✓ Affordable Fees
                      </span>
                      <span className="bg-slate-100 text-[#0056b3] text-[10px] font-bold px-2.5 py-1 rounded-full">
                        ✓ ISO Aligned
                      </span>
                      <span className="bg-slate-100 text-emerald-600 text-[10px] font-bold px-2.5 py-1 rounded-full">
                        ✓ Career Mentoring
                      </span>
                    </div>
                  </div>

                  {/* Animated Counters Dashboard Card */}
                  <div className="space-y-3">
                    <div className="flex justify-between items-center px-1">
                      <h4 className="text-xs font-extrabold text-[#002147] uppercase tracking-wider font-mono">
                        📊 Live Candidate Metrics
                      </h4>
                      <span className="text-[10px] text-[#ff8c00] font-semibold">Real-time stats</span>
                    </div>
                    <StatsGrid stats={stats} />
                  </div>

                  {/* Custom Promo Video Embed Section - Mock player look */}
                  <div className="space-y-3">
                    <div className="flex justify-between items-center px-1">
                      <h4 className="text-xs font-extrabold text-[#002147] uppercase tracking-wider font-mono">
                        📹 Video Classroom & Demos
                      </h4>
                      <span className="text-[10px] text-blue-600 font-semibold font-mono">4 core tutorials</span>
                    </div>

                    <div className="grid grid-cols-1 gap-4">
                      {videos.slice(0, 2).map(vid => (
                        <div key={vid.id} className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs group">
                          {/* Emulated iframe wrapper with play action overlay */}
                          <div className="relative aspect-video bg-slate-900 flex items-center justify-center">
                            <iframe 
                              className="w-full h-full"
                              src={`https://www.youtube.com/embed/${vid.embedId}?si=${vid.si}`}
                              title={vid.title}
                              frameBorder="0"
                              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                              allowFullScreen
                            ></iframe>
                          </div>
                          <div className="p-3 bg-white flex justify-between items-center">
                            <span className="text-xs font-bold text-slate-700 font-display">{vid.title}</span>
                            <span className="text-[9px] bg-red-100 text-red-600 px-2 py-0.5 rounded font-mono font-bold uppercase">
                              YouTube Class
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Why Choose Checklist */}
                  <div className="bg-gradient-to-br from-[#002147] to-[#041d38] p-5 rounded-2xl text-white">
                    <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-1.5 font-display">
                      <Award className="w-4 h-4 text-[#ff8c00]" /> Why Choose SC World Technology?
                    </h3>
                    <div className="grid grid-cols-2 gap-3 text-xs">
                      {[
                        'Experienced Mentors',
                        'Job-Oriented Material',
                        'Practical Case Studies',
                        'Real Career Support',
                        'Trustworthy & Standard',
                        'Government Alignments',
                        'Budget technical fees',
                        'Fast Admissions Process'
                      ].map((item, idx) => (
                        <div key={idx} className="flex items-center gap-1.5 text-slate-100">
                          <CheckCircle2 className="w-3.5 h-3.5 text-green-400 shrink-0" />
                          <span className="text-[11px] font-sans font-medium">{item}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Play store promo block inside tabs */}
                  <PlayStoreBanner />

                  {/* Social Handles */}
                  <div className="text-center space-y-3 pt-2">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                      Connect globally via Social channels
                    </span>
                    <div className="flex justify-center flex-wrap gap-2.5">
                      {socialLinks.map(link => (
                        <a
                          key={link.platform}
                          href={link.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="w-8 h-8 rounded-full flex items-center justify-center transition-transform hover:scale-110 active:scale-95"
                          style={{ backgroundColor: link.color }}
                          title={link.platform}
                        >
                          {renderSocialIcon(link.platform)}
                        </a>
                      ))}
                    </div>
                  </div>

                  {/* Trust footer block */}
                  <div className="text-center py-2 text-[10px] text-slate-400 border-t border-slate-200 select-none">
                    🇮🇳 A proud Skill Development Initiative supporting Technical India
                  </div>

                </div>
              </div>
            )}

            {/* -------------------- TAB CONTENT: SERVICES -------------------- */}
            {activeTab === 'services' && (
              <div className="p-5 flex-1 space-y-6 bg-slate-50">
                <div className="text-center max-w-sm mx-auto">
                  <h3 className="text-lg font-extrabold text-[#002147] font-display">
                    Our Premium Services
                  </h3>
                  <p className="text-xs text-slate-500 mt-1">
                    Comprehensive digital education, software blueprints, and local smart governance.
                  </p>
                </div>

                {/* Grid */}
                <div className="grid grid-cols-1 gap-3.5">
                  {services.map((item) => (
                    <div 
                      key={item.id}
                      className="bg-white border border-slate-200/90 hover:border-[#0056b3] rounded-2xl p-4 shadow-xs flex items-start gap-4 transition-all"
                    >
                      <div className="p-2.5 bg-slate-50 rounded-xl shrink-0">
                        {renderServiceIcon(item.icon)}
                      </div>
                      
                      <div className="flex-1 space-y-1">
                        <div className="flex justify-between items-center">
                          <h4 className="text-sm font-bold text-[#002147] font-display">
                            {item.title}
                          </h4>
                          <span className="text-[9px] bg-blue-50 text-blue-600 px-2 py-0.5 rounded-full font-bold">
                            Active
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 leading-relaxed font-sans font-medium">
                          {item.description}
                        </p>
                        
                        <div className="pt-2">
                          <a 
                            href={item.link} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 text-[11px] font-bold text-[#0056b3] hover:underline"
                          >
                            <span>Learn Details</span>
                            <ArrowUpRight className="w-3 h-3" />
                          </a>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <PlayStoreBanner />
              </div>
            )}

            {/* -------------------- TAB CONTENT: COURSES -------------------- */}
            {activeTab === 'courses' && (
              <div className="p-5 flex-1 space-y-6 bg-slate-50">
                <div className="text-center max-w-sm mx-auto">
                  <h3 className="text-lg font-extrabold text-[#002147] font-display">
                    Featured Computer Programs
                  </h3>
                  <p className="text-xs text-slate-500 mt-1">
                    Job-oriented industry aligned curriculum to jumpstart your career.
                  </p>
                </div>

                {/* Course Search shortcut */}
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                  <input 
                    type="text" 
                    placeholder="Search by keywords (e.g., Python, Office, Tally)..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-xl pl-9.5 pr-4 py-2.5 text-xs outline-none focus:border-blue-500 transition-all font-sans"
                  />
                </div>

                <div className="grid grid-cols-1 gap-3.5">
                  {filteredCourses.map((c) => (
                    <div 
                      key={c.id}
                      className="bg-[#002147] text-white rounded-2xl p-4 shadow-md space-y-2.5 hover:shadow-lg transition-shadow relative overflow-hidden"
                    >
                      <div className="absolute right-0 top-0 w-24 h-24 bg-white/5 rounded-full translate-x-8 -translate-y-8"></div>
                      
                      <div className="flex justify-between items-center relative z-10">
                        <h4 className="text-sm font-extrabold text-white font-display">
                          {c.title}
                        </h4>
                        <span className="text-[9px] bg-orange-500 text-white font-bold px-2 py-0.5 rounded-full uppercase">
                          Free Training
                        </span>
                      </div>
                      
                      <p className="text-xs text-slate-300 relative z-10 leading-relaxed">
                        {c.description}
                      </p>
                      
                      <div className="pt-1.5 flex justify-between items-center relative z-10">
                        <span className="text-[10px] text-slate-400 font-mono flex items-center gap-1">
                          🗂️ ISO 9001 Certified
                        </span>
                        
                        <a 
                          href="https://www.scworldtechnology.in/p/sign-up-form.html" 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="px-3 py-1 bg-[#ff8c00] text-black text-xs font-bold rounded-lg hover:bg-white hover:text-[#002147] transition-all flex items-center gap-1"
                        >
                          <span>Apply Now</span>
                          <ChevronRight className="w-3 h-3" />
                        </a>
                      </div>
                    </div>
                  ))}

                  {filteredCourses.length === 0 && (
                    <div className="text-center p-8 bg-slate-100 rounded-2xl">
                      <p className="text-xs text-slate-500 font-medium">
                        No courses match "{searchQuery}". Try typing basic, AI, or advanced!
                      </p>
                    </div>
                  )}
                </div>

                {/* Rest of YouTube Classes */}
                <div>
                  <h4 className="text-xs font-bold text-[#002147] uppercase tracking-wider mb-3.5 pl-1">
                    🔴 More Classrooms
                  </h4>
                  <div className="grid grid-cols-1 gap-3">
                    {videos.slice(2, 4).map(vid => (
                      <div key={vid.id} className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
                        <div className="relative aspect-video">
                          <iframe 
                            className="w-full h-full"
                            src={`https://www.youtube.com/embed/${vid.embedId}?si=${vid.si}`}
                            title={vid.title}
                            frameBorder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowFullScreen
                          ></iframe>
                        </div>
                        <div className="p-3.5 bg-white text-xs font-bold text-slate-700">
                          {vid.title}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <PlayStoreBanner />
              </div>
            )}

            {/* -------------------- TAB CONTENT: JOBS -------------------- */}
            {activeTab === 'jobs' && (
              <div className="p-5 flex-1 space-y-6 bg-slate-50">
                <div className="text-center max-w-sm mx-auto">
                  <h3 className="text-lg font-extrabold text-[#002147] font-display">
                    Daily India Job Feeds
                  </h3>
                  <p className="text-xs text-slate-500 mt-1">
                    Notifications of central, state government slots & leading software openings.
                  </p>
                </div>

                <div className="space-y-4">
                  {jobUpdates.map((job) => (
                    <div 
                      key={job.id} 
                      className="bg-white border-l-4 border-[#0056b3] rounded-r-2xl p-4.5 shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between gap-4"
                    >
                      <div className="space-y-1.5">
                        <div className="flex justify-between items-center">
                          <h4 className="text-sm font-extrabold text-slate-800 font-display">
                            {job.title}
                          </h4>
                          <span className="text-[10px] bg-sky-100 text-sky-800 font-bold px-2 py-0.5 rounded-full">
                            {job.tag}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 leading-relaxed font-sans font-medium">
                          {job.description}
                        </p>
                      </div>

                      <div className="flex justify-between items-center pt-2 border-t border-slate-100">
                        <span className="text-[10px] text-slate-400 font-mono">
                          ⚡ Updated Daily
                        </span>
                        
                        <a 
                          href="https://whatsapp.com/channel/0029VaA9bbSJuyA6RxHrS12M" 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="px-3.5 py-1.5 bg-blue-600 text-white text-xs font-bold rounded-lg hover:bg-blue-700 transition-colors inline-flex items-center gap-1 shadow-xs"
                        >
                          <span>Get Live Alerts</span>
                          <ArrowUpRight className="w-3.5 h-3.5" />
                        </a>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="bg-[#fff2e6] border border-orange-200 p-4 rounded-2xl">
                  <h4 className="text-xs font-extrabold text-[#994d00] uppercase tracking-wider mb-1">
                    🔔 Urgent Application Notice
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed font-sans">
                    Make sure to click our online registration and submit correct credentials via the direct Google Form so that counselors can verify your ISO technical certification correctly!
                  </p>
                  <div className="mt-3">
                    <a 
                      href="https://www.scworldtechnology.in/p/sign-up-form.html" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-xs font-extrabold text-[#ff6f00] hover:underline flex items-center gap-1"
                    >
                      <span>Fill Out Registration Form</span>
                      <ArrowUpRight className="w-3 h-3" />
                    </a>
                  </div>
                </div>

                <PlayStoreBanner />
              </div>
            )}

            {/* -------------------- TAB CONTENT: ASSISTANT CHAT -------------------- */}
            {activeTab === 'chat' && (
              <div className="flex-grow flex flex-col h-full overflow-hidden">
                <AIChatBot onNotify={triggerNotification} />
              </div>
            )}

          </div>

          {/* Persistent Inline Notification Alerts */}
          {announcementNotify && (
            <div className="absolute top-16 left-4 right-4 bg-blue-600 text-white font-semibold text-xs tracking-wide py-2.5 px-4 rounded-xl shadow-lg border border-blue-500 z-50 flex items-center justify-between transition-all select-none animate-bounce">
              <span>{announcementNotify}</span>
              <button onClick={() => setAnnouncementNotify('')}>
                <X className="w-4.5 h-4.5" />
              </button>
            </div>
          )}

          {/* Interactive Cookie Consent Banner inside device Frame */}
          {!cookieConsent && (
            <div className="absolute bottom-16 left-4 right-4 bg-slate-950 text-white p-4 rounded-2xl shadow-2xl border border-slate-800 z-50 space-y-3 select-none">
              <p className="text-[11px] text-slate-300 leading-relaxed font-sans">
                🍪 <strong>SC WORLD TECHNOLOGY</strong> uses cookies to analyze technical traffic and provide high quality certification services. Accept them to proceed!
              </p>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleCookieAccept}
                  className="flex-1 py-1.5 bg-green-500 hover:bg-green-600 text-black font-extrabold text-[11px] rounded transition-transform active:scale-95"
                >
                  Accept
                </button>
                <button
                  onClick={handleCookieDecline}
                  className="flex-1 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-400 text-[11px] rounded transition-transform active:scale-95"
                >
                  Decline
                </button>
              </div>
            </div>
          )}

          {/* Persistent Simulated Bottom Navigation Bar */}
          <div className="bg-[#001733] border-t border-white/10 px-3.5 py-2.5 grid grid-cols-5 text-center text-white shrink-0 select-none z-10">
            <button
              onClick={() => setActiveTab('home')}
              className={`flex flex-col items-center gap-1 transition-all outline-none ${
                activeTab === 'home' ? 'text-[#ff8c00] scale-110' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Home className="w-5 h-5 shrink-0" />
              <span className="text-[9px] font-bold font-sans tracking-tight">Home</span>
            </button>

            <button
              onClick={() => setActiveTab('services')}
              className={`flex flex-col items-center gap-1 transition-all outline-none ${
                activeTab === 'services' ? 'text-[#ff8c00] scale-110' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Grid className="w-5 h-5 shrink-0" />
              <span className="text-[9px] font-bold font-sans tracking-tight">Services</span>
            </button>

            <button
              onClick={() => setActiveTab('courses')}
              className={`flex flex-col items-center gap-1 transition-all outline-none ${
                activeTab === 'courses' ? 'text-[#ff8c00] scale-110' : 'text-slate-400 hover:text-white'
              }`}
            >
              <GraduationCap className="w-5 h-5 shrink-0" />
              <span className="text-[9px] font-bold font-sans tracking-tight">Courses</span>
            </button>

            <button
              onClick={() => setActiveTab('jobs')}
              className={`flex flex-col items-center gap-1 transition-all outline-none ${
                activeTab === 'jobs' ? 'text-[#ff8c00] scale-110' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Briefcase className="w-5 h-5 shrink-0" />
              <span className="text-[9px] font-bold font-sans tracking-tight">Jobs</span>
            </button>

            <button
              onClick={() => setActiveTab('chat')}
              className={`flex flex-col items-center gap-1 transition-all outline-none relative ${
                activeTab === 'chat' ? 'text-[#ff8c00] scale-110' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Bot className="w-5 h-5 shrink-0 animate-pulse" />
              <span className="text-[9px] font-bold font-sans tracking-tight">AI Chat</span>
              <span className="absolute top-0 right-3.5 w-2 h-2 bg-red-500 rounded-full animate-ping"></span>
            </button>
          </div>

        </div>

      </div>

    </div>
  );
}
