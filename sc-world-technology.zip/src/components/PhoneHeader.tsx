import React, { useState, useEffect } from 'react';

export default function PhoneHeader() {
  const [time, setTime] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      let hours = now.getHours();
      const minutes = now.getMinutes().toString().padStart(2, '0');
      const ampm = hours >= 12 ? 'PM' : 'AM';
      hours = hours % 12;
      hours = hours ? hours : 12; // first hour is 12
      setTime(`${hours}:${minutes} ${ampm}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 30000); // update every 30s
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex justify-between items-center px-5 py-2.5 bg-[#001733] text-white text-xs font-medium select-none border-b border-white/5 tracking-wider w-full">
      {/* Time */}
      <span className="font-semibold text-slate-200">{time || '1:50 PM'}</span>
      
      {/* Notches or speaker visual dummy */}
      <div className="w-16 h-3.5 bg-black/40 rounded-full hidden sm:block"></div>

      {/* Status Icons */}
      <div className="flex items-center gap-2 text-slate-300">
        {/* Cellular Connection */}
        <div className="flex items-end gap-0.5 h-2.5 w-3.5" title="Full LTE signals">
          <div className="w-0.5 h-1 bg-current rounded-3xs"></div>
          <div className="w-0.5 h-1.5 bg-current rounded-3xs"></div>
          <div className="w-0.5 h-2 bg-current rounded-3xs"></div>
          <div className="w-0.5 h-2.5 bg-current rounded-3xs"></div>
        </div>

        {/* Network / WiFi */}
        <svg 
          className="w-3.5 h-3.5" 
          fill="none" 
          stroke="currentColor" 
          viewBox="0 0 24 24" 
          strokeWidth="2.5"
        >
          <path d="M12 20h.01M8.5 16.5a5 5 0 0 1 7 0M5.5 13.5a9 9 0 0 1 13 0M1.5 9.5a15 15 0 0 1 21 0" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>

        {/* Battery Container */}
        <div className="flex items-center gap-0.5 border border-slate-300 rounded-[3px] p-[1.5px] w-5.5 h-3">
          <div className="h-full w-full bg-emerald-500 rounded-[1px]"></div>
          <div className="w-[1.5px] h-1 bg-slate-300 rounded-r-2xs -mr-[3px]"></div>
        </div>
      </div>
    </div>
  );
}
