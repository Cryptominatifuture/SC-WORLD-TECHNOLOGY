import React, { useState, useEffect } from 'react';
import { Briefcase, Settings, Lightbulb, Users, TrendingUp } from 'lucide-react';
import { Stat } from '../types';

interface StatsGridProps {
  stats: Stat[];
}

const iconMap: { [key: string]: any } = {
  Briefcase: Briefcase,
  Settings: Settings,
  Lightbulb: Lightbulb,
  Users: Users,
  TrendingUp: TrendingUp,
};

export default function StatsGrid({ stats }: StatsGridProps) {
  const [counts, setCounts] = useState<{ [key: string]: number }>({});

  useEffect(() => {
    // Initialize
    const initialCounts: { [key: string]: number } = {};
    stats.forEach(s => {
      initialCounts[s.id] = 0;
    });
    setCounts(initialCounts);

    const duration = 1500; // 1.5s animation duration
    const steps = 40;
    const intervalTime = duration / steps;
    let stepCount = 0;

    const timer = setInterval(() => {
      stepCount++;
      setCounts(prev => {
        const next = { ...prev };
        stats.forEach(s => {
          const increment = s.target / steps;
          const currentVal = Math.min(s.target, Math.ceil(increment * stepCount));
          next[s.id] = currentVal;
        });
        return next;
      });

      if (stepCount >= steps) {
        clearInterval(timer);
      }
    }, intervalTime);

    return () => clearInterval(timer);
  }, [stats]);

  const formatNumber = (num: number, id: string) => {
    if (id === 'daily-visitors') {
      return num >= 1000000 ? '1M' : num.toLocaleString();
    }
    return num.toLocaleString();
  };

  return (
    <div className="grid grid-cols-2 xs:grid-cols-2 md:grid-cols-5 gap-3.5 my-6">
      {stats.map((s) => {
        const IconComponent = iconMap[s.icon] || Briefcase;
        return (
          <div 
            key={s.id} 
            className="bg-white/80 border border-slate-200/90 rounded-2xl p-4.5 shadow-xs transition-all hover:shadow-md hover:border-blue-500/50 flex flex-col items-center text-center group"
          >
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-[#0056b3] flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
              <IconComponent className="w-5.5 h-5.5" />
            </div>
            
            <h3 className="text-xl font-bold text-[#ff6f00] font-display select-none">
              {formatNumber(counts[s.id] || 0, s.id)}
              {s.suffix}
            </h3>
            
            <p className="text-[11px] font-semibold text-slate-500 tracking-wider uppercase mt-1">
              {s.label}
            </p>
          </div>
        );
      })}
    </div>
  );
}
