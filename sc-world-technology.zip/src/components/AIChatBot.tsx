import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bot, Send, Mic, Volume2, Sparkles, MessageSquare, X, ChevronRight, User } from 'lucide-react';
import { getBotResponse } from '../data';
import { Message } from '../types';

interface AIChatBotProps {
  onNotify?: (message: string) => void;
}

export default function AIChatBot({ onNotify }: AIChatBotProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome-1',
      sender: 'bot',
      text: '👋 Welcome to **SC WORLD TECHNOLOGY**!<br><br>I am your smart virtual advisor. Tap any category below or text me your question to get instant premium career & IT support! 🤖',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Quick action suggestions mapping
  const promptSuggestions = [
    { label: '📚 Web Courses', keyword: 'courses' },
    { label: '🧑‍💼 Jobs Portal', keyword: 'job updates' },
    { label: '🤖 AI Services', keyword: 'ai chatbot' },
    { label: '💻 Make Website', keyword: 'website' },
    { label: '📈 Ranking & SEO', keyword: 'seo keyword' },
    { label: '📞 Contact Call', keyword: 'contact support' }
  ];

  // Auto-scroll on new message
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSendMessage = (textToSend: string) => {
    if (!textToSend.trim()) return;

    // Add user message
    const userMsg: Message = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setIsTyping(true);

    // Simulate bot replying with actual rules
    setTimeout(() => {
      const responseText = getBotResponse(textToSend);
      const botMsg: Message = {
        id: `bot-${Date.now()}`,
        sender: 'bot',
        text: responseText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, botMsg]);
      setIsTyping(false);
      
      if (onNotify) {
        onNotify(`AI Assistant: New response populated!`);
      }
    }, 1000);
  };

  // Web Speech API Voice Recognition
  const handleVoiceInput = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Voice recognition is not supported in this browser. Please try Chrome, Edge, or Safari.");
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'en-IN';
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputText(transcript);
        setIsListening(false);
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } catch {
      setIsListening(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 overflow-hidden relative font-sans">
      {/* Bot Header */}
      <div className="bg-[#002147] border-b border-white/10 px-4 py-3 flex items-center justify-between shadow-md">
        <div className="flex items-center gap-3">
          <div className="relative">
            <img 
              src="https://i.ibb.co/Q3wfxZqW/cute-cartoon-robot-assistant-artificial-intelligence-online-support-vector.jpg" 
              alt="Bot Assistant" 
              className="w-10 h-10 rounded-full border border-blue-400 object-cover"
              referrerPolicy="no-referrer"
            />
            <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-[#002147] rounded-full animate-pulse"></span>
          </div>
          <div>
            <h3 className="font-semibold text-white text-sm tracking-wide font-display">SC AI SmartBot</h3>
            <span className="text-[11px] text-green-400 flex items-center gap-1 font-mono font-medium">
              <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-ping"></span>
              Online Support
            </span>
          </div>
        </div>

        {/* Support quick details */}
        <div className="text-[10px] text-slate-300 font-mono text-right hidden sm:block">
          <div>v2.4 Live AI</div>
          <div>Jabalpur, MP</div>
        </div>
      </div>

      {/* Messages Sandbox */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-4 space-y-3.5 bg-[#08101a] scroll-smooth"
      >
        {messages.map((msg) => (
          <motion.div
            key={msg.id}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2 }}
            className={`flex items-start gap-2.5 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            {msg.sender === 'bot' && (
              <div className="w-7 h-7 rounded-full bg-blue-950 border border-blue-900 flex items-center justify-center shrink-0 mt-0.5 shadow-sm text-blue-400">
                <Bot className="w-4 h-4" />
              </div>
            )}

            <div className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-xs shadow-sm leading-relaxed ${
              msg.sender === 'user' 
                ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-tr-none' 
                : 'bg-slate-800 border border-slate-700/60 text-slate-200 rounded-tl-none font-sans'
            }`}>
              {/* Message text with basic HTML support because of mapping tags */}
              <div 
                dangerouslySetInnerHTML={{ __html: msg.text }} 
                className="prose prose-invert max-w-none text-slate-200"
              />
              <span className={`block text-[9px] mt-1.5 font-mono ${
                msg.sender === 'user' ? 'text-blue-200/80 text-right' : 'text-slate-500'
              }`}>
                {msg.timestamp}
              </span>
            </div>

            {msg.sender === 'user' && (
              <div className="w-7 h-7 rounded-full bg-slate-700 flex items-center justify-center shrink-0 mt-0.5 text-white shadow-sm font-semibold text-[10px]">
                <User className="w-4.5 h-4.5 text-slate-300" />
              </div>
            )}
          </motion.div>
        ))}

        {isTyping && (
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-full bg-blue-950 border border-blue-900 flex items-center justify-center text-blue-400 shadow-sm shrink-0">
              <Bot className="w-4 h-4 animate-bounce" />
            </div>
            <div className="bg-slate-800 border border-slate-700/60 rounded-2xl rounded-tl-none px-3.5 py-3 text-xs text-slate-400 flex items-center gap-1.5 shadow-sm">
              <span className="w-1.5 h-1.5 bg-[#ff8c00] rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
              <span className="w-1.5 h-1.5 bg-[#ff8c00] rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
              <span className="w-1.5 h-1.5 bg-[#ff8c00] rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
              <span className="ml-1 text-[11px] font-mono tracking-wide text-slate-500">SC AI is drafting...</span>
            </div>
          </div>
        )}
      </div>

      {/* Suggestion Chips */}
      <div className="px-3 py-2 bg-[#050b10] border-t border-slate-800/80 overflow-x-auto flex gap-2 scrollbar-none shrink-0 select-none">
        {promptSuggestions.map((sug) => (
          <button
            key={sug.label}
            onClick={() => handleSendMessage(sug.keyword)}
            className="shrink-0 bg-slate-800/80 hover:bg-blue-900/60 border border-slate-700/60 hover:border-blue-500/50 text-[11px] text-slate-300 hover:text-white rounded-full px-3 py-1.5 transition-all flex items-center gap-1 active:scale-95"
          >
            <span>{sug.label}</span>
            <ChevronRight className="w-3 h-3 text-slate-500" />
          </button>
        ))}
      </div>

      {/* Input controls panel */}
      <div className="p-3 bg-[#03070b] border-t border-slate-800/85 flex items-center gap-2 shrink-0">
        <button
          onClick={handleVoiceInput}
          type="button"
          className={`p-2.5 rounded-xl transition-all shadow-sm ${
            isListening 
              ? 'bg-red-500 text-white animate-pulse' 
              : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white active:scale-90'
          }`}
          title="Mic: Tap to speak Hindi/English"
        >
          <Mic className="w-4.5 h-4.5" />
        </button>

        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') handleSendMessage(inputText);
          }}
          placeholder={isListening ? "Listening... Speak now..." : "Type Courses, Jobs, Web, CONTACT..."}
          className="flex-1 bg-slate-800/90 text-slate-100 placeholder-slate-500 rounded-xl px-3.5 py-2.5 text-xs outline-none border border-slate-700/80 focus:border-blue-500 focus:bg-slate-800 transition-all font-sans"
        />

        <button
          onClick={() => handleSendMessage(inputText)}
          disabled={!inputText.trim()}
          className="p-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white transition-all hover:shadow-md disabled:bg-slate-800 disabled:text-slate-600 disabled:shadow-none active:scale-95"
        >
          <Send className="w-4.5 h-4.5" />
        </button>
      </div>

      {/* Embedded Whatsapp redirection strip inside helper */}
      <div className="bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] text-center font-semibold py-1.5 flex items-center justify-center gap-1.5 transition-all select-none">
        <span className="w-1.5 h-1.5 bg-white rounded-full animate-ping"></span>
        <a 
          href="https://wa.me/916264169913" 
          target="_blank" 
          rel="noopener noreferrer" 
          className="hover:underline flex items-center gap-1 font-display"
        >
          Need Direct Help? WhatsApp support active now! 💬
        </a>
      </div>
    </div>
  );
}
