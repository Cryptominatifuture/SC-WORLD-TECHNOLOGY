import React from 'react';
import { ArrowUpRight } from 'lucide-react';

export default function PlayStoreBanner() {
  return (
    <div className="bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 rounded-3xl p-6 shadow-xl text-center font-sans tracking-wide">
      <div className="inline-flex items-center justify-center w-12 h-12 bg-blue-500/10 border border-blue-500/20 text-blue-400 rounded-2xl mb-4">
        📱
      </div>
      
      <h2 className="text-xl font-bold text-white mb-2 font-display">📱 Download Official Mobile App</h2>
      
      <p className="text-xs text-slate-400 leading-relaxed max-w-sm mx-auto mb-5">
        Install our official mobile application from Google Play Store 
        and get fast access to all services, skill courses, and instant job alerts anytime anywhere.
      </p>

      <div className="flex flex-col items-center gap-3">
        {/* PlayStore Link */}
        <a 
          href="https://play.google.com/store/apps/details?id=co.median.android.lpmkapd" 
          target="_blank" 
          rel="noopener noreferrer"
          className="inline-block transition-transform hover:scale-105 active:scale-95"
        >
          <img 
            src="https://upload.wikimedia.org/wikipedia/commons/7/78/Google_Play_Store_badge_EN.svg" 
            alt="Download on Google Play Store" 
            className="w-44 h-auto"
            referrerPolicy="no-referrer"
          />
        </a>

        {/* Median App specs metadata */}
        <span className="text-[10px] text-slate-500 font-mono flex items-center gap-1">
          App ID: co.median.android.lpmkapd <ArrowUpRight className="w-3 h-3 text-slate-600" />
        </span>
      </div>
    </div>
  );
}
