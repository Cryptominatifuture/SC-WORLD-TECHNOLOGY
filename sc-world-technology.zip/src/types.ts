export interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
  link: string;
}

export interface Course {
  id: string;
  title: string;
  description: string;
}

export interface Stat {
  id: string;
  icon: string;
  target: number;
  label: string;
  prefix?: string;
  suffix?: string;
}

export interface Message {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
}

export interface SocialLink {
  platform: string;
  icon: string;
  url: string;
  color: string;
}

export interface JobCard {
  id: string;
  title: string;
  description: string;
  tag: string;
}
